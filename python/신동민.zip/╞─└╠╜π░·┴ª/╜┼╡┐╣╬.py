from modeul import md_Ext                      # 폴더 내의 파일 확장자를 찾는 모듈
from modeul import md_byte                     # 찾은 확장자의 파일들 각각의 용량을 구하는 모듈
from modeul import md_filelist                 # 찾은 확장자의 각각의 파일이름을 출력하는 모듈
from modeul import md_dircount                 # 폴더 내의 폴더의 수를 출력하는 모듈
#a="c:/windows/"
a = "한글.txt"
#a = "2017305039신동민1.txt"
#a = "2017305039신동민2.txt"
f = open(a, 'r', encoding='UTF8')              # 저장된 txt 파일을 파이참에서 오픈한다.
file = f.readlines()                           # 파일의 각 라인을 원소로 하는 리스트 자료형이 반환된다.
f.close()


listA, listB = md_Ext.SearchExt()              # 각 모듈의 함수를 실행하고 리턴값을 받아준다.
listC = md_byte.byteSum()
listD = md_filelist.filelist()


print("확장자의 개수와 각 학장자에 따른 파일의 수를 출력하시오.")
print("\t 확장자:\t   개수:\t   파일크기의 합:\t  퍼센트 용량:\t 파일 리스트")
for i in range(len(listA)):
    print("{:>10}: {:>7,}{:>15,}{:13.6f}%\t{}".format(listA[i], listB[i], listC[i], listC[i]/(sum(listC)*1.0), listD[i]))
# 모듈에서 계산한 값을 순서에 맞게 format()에 넣어 출력한다.

Dir_count = md_dircount.Dircount()             # 폴더를 구할때 폴더이름도 출력하게 만들어서 이자리에 있어야 한다.


print("총 확장자의 수={:,}, 폴더의 수={:,}, 총 파일의 수={:,}, 총 용량={:,}".format(len(listA), Dir_count-2, sum(listB), sum(listC)))
# 마지막으로 앞에서 했던 값들을 출력한다.
