from modeul import md_Ext               # 기본적으로 확장자를 찾아서 실행하는 기반으로 만들었다.
#a="c:/windows/"
a ="../파이썬과제/한글.txt"
#a ="../파이썬과제/2017305039신동민1.txt"
#a ="../파이썬과제/2017305039신동민2.txt"
f = open(a, 'r', encoding='UTF8')       # 저장된 txt 파일을 파이참에서 오픈한다.
file = f.readlines()                    # 파일의 각 라인을 원소로 하는 리스트 자료형이 반환된다.
f.close()
listA, listB = md_Ext.SearchExt()


def listname(i):                        # 각 확장자마다 파일을 찾고 이름만 나오게 처리한 리스트를 반환한다.
    listname1 = []
    for j in range(len(file)):
        if file[j].count(i) == 1:
            Temp = file[j].split(' ')
            listname1.append(Temp[-1].replace('.', '').replace(i, '').replace('\n', ''))
    return listname1


def filelist():                          # 각 확장자가 있는 파일들의 이름을 나열한 리스트를 반환한다.
    listD = []
    for i in listA:
        listD.append(listname(i))
    return listD
