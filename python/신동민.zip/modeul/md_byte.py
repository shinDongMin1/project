from modeul import md_Ext              # 기본적으로 확장자를 찾아서 실행하는 기반으로 만들었다.
#a="c:/windows/"
a ="../파이썬과제/한글.txt"
#a ="../파이썬과제/2017305039신동민1.txt"
#a ="../파이썬과제/2017305039신동민2.txt"
f = open(a, 'r', encoding='UTF8')      # 저장된 txt 파일을 파이참에서 오픈한다.
file = f.readlines()                   # 파일의 각 라인을 원소로 하는 리스트 자료형이 반환된다
f.close()
listA, listB = md_Ext.SearchExt()      # 확장자의 수가 달라 질수도 있어서


def bytesearch(i):                     # 확장자마다 그 확장자에 파일을 찾아 용량을 합한다.
    Sum = 0
    for j in range(len(file)):
        if file[j].count(i) == 1:
            Temp1 = file[j].split(' ')
            Temp2 = (Temp1[-2].replace(',', ''))
            Sum += int(Temp2)
    return Sum


def byteSum():                         # listA는 확장자들이 들어가 있는데 확장자마다 용량을 구한다.
    listC = []                         # 용량을 구했으면 리스트형태로 반환한다.
    for i in listA:
        listC.append(bytesearch(i))
    return listC


