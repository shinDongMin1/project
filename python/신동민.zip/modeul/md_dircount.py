#a="c:/windows/"
a ="../파이썬과제/한글.txt"
#a ="../파이썬과제/2017305039신동민1.txt"
#a ="../파이썬과제/2017305039신동민2.txt"
f = open(a, 'r', encoding='UTF8')        # 저장된 txt 파일을 파이참에서 오픈한다.
file = f.readlines()                     # 파일의 각 라인을 원소로 하는 리스트 자료형이 반환된다.
f.close()


def Dircount():
    Dir_count = 0                                    # 폴더의 수의 변수에 초기값을 설정한다.
    for i in range(len(file)):
        if file[i].count("<DIR>") == 1:              # 리스트자료형에 각 인덱스마다 <DIR>가 있는지 확인하고
          Search = file[i].split(' ')                # 공백마다 나눠 리스트원소로 받는다.
          Dir_count += 1                             # 폴더의 수를 카운트한다.
          if Dir_count > 2:
              print("  <{}>".format(Search[-1].replace('\n', '')))    # 폴더의 이름을 출력한다.
    return Dir_count

