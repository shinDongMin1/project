#a="c:/windows/"
a ="../파이썬과제/한글.txt"
#a ="../파이썬과제/2017305039신동민1.txt"
#a ="../파이썬과제/2017305039신동민2.txt"
f = open(a, 'r', encoding='UTF8')               # 저장된 txt 파일을 파이참에서 오픈한다.
file = f.readlines()                            # 파일의 각 라인을 원소로 하는 리스트 자료형이 반환된다.
f.close()


def countExt(list3, n):                         # 각 확장자의 개수를 찾는다.
    count = 0
    for i in range(len(list3)):
        if list3[i] == n:
            count += 1
    return count


def SearchExt():                                # 파일들의 확장자들을 찾아 알파벳순으로 정렬한 리스트와
    list2 = []                                  # 각 확장자의 수를 반환한다.
    list3 = []
    for j in range(len(file)):
        if file[j].count("<DIR>") == 0:
            Temp1 = file[j].split(' ')
            if Temp1.count('오전') == 1 or Temp1.count('오후') == 1:
                Temp2 = Temp1[-1].split('.')
                Temp3 = len(Temp2[-1].split(' '))
                if Temp3 <= 10:
                    list3.append(Temp2[-1].replace('\n', ''))
    list1 = list(set(list3))
    list1.sort()

    for i in list1:
       list2.append(countExt(list3, i))
    return list1, list2

