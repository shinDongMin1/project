abstract class Figure{
	abstract void area();
	abstract void girth();
	abstract void draw();
}

class Circle extends Figure{
	double r;
	Circle(){r=1;}
	Circle(double x){r=x;}
	public void area() {System.out.println("���� ����="+r*r*3.14);}
	public void girth() {System.out.println("���� �ѷ�="+r*2*3.14);}
	public void draw() {double x; double y; for(x=-2*r;x <= 2*r; x+=2) {
        for(y=-r;y<=r;y++) {
            if((x*x+y*y)>=r*r-r/1.3 &&(x*x+y*y)<=r*r+r/1.3)
                System.out.print("*");
            else
                System.out.print(" ");
        }
        System.out.println("");
    }}
}
class Square extends Figure{
	double line1;
	double line2;
	Square(){line1=1;line2=1;}
	Square(double x, double y) {line1=x;line2=y;}
	public void area() {System.out.println("�簢���� ����="+line1*line2);}
	public void girth() {System.out.println("�簢���� �ѷ�="+(line1*2+line2*2));}
	public void draw() {
		for(int i = 0; i < line1; i++) {
			for(int j=0; j < line2; j++) {
		        System.out.print("*");
			}
	    System.out.println("");
		}
	}
}
public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c = new Circle(2);
		c.area();
		c.girth();
		c.draw();
		Square s = new Square(2,3);
		s.area();
		s.girth();
		s.draw();
	}

}
