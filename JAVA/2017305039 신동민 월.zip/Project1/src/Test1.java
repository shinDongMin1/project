import java.io.*;
import java.util.Scanner;

class Stack{
	private int[] stack;
	int sp = 0;
	Stack(){ stack = new int[10];}

	public void push(int data) {if(sp == 10) System.out.println("overflow"); else stack[sp++] =data;}
	public int pop() { return stack[--sp];}
	public void print(int x) {for(int i = 0; i < x; i++) System.out.printf("%-4d ", stack[i]);}
}

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Stack st = new Stack();
		int a, n = 5;
		System.out.print("�Է��Ͻÿ�:");
		for(int i = 0; i < n; i++) {
			a= sc.nextInt();
			st.push(a);
		}
		st.print(n);
		System.out.println("");
		for(int i = 0; i < n; i++) 
			System.out.printf("%-4d ", st.pop());
	}

}
