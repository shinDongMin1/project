
class Complex{
	double real;
	double image;
	Complex() {real = 0; image = 0;}
	Complex(double num) {real = num; image = num;}
	Complex(double num1, double num2) {real = num1; image = num2;}
	
	public Complex addComplex(Complex f) {real = real+f.real; image = image+f.image; return this;}
	public Complex mulComplex(Complex f) {real = (real*f.real)-(image*f.image);
										  image = (real*f.image)+(f.real*image); return this;}

	public String toString() {
		String s;
	if(real != 0 && image != 0) {
		if(image > 0) {
			if(image == 1)
				s = real+"+i";
			else
				s = real+"+"+image+"i";
		}
		else {
			if(image == -1)
				s = real+"-i";
			else
				s = real+""+image+"i";
		}
	}
	else if(real == 0 && image != 0) {
		if(image == -1)
			s = "-i";
		else if(image == 1)
			s = "i";
		else
			s = image+"i";
	}
	else if(real != 0 && image == 0) {
		s = real+"";
	}
	else
		s = "";
		
	return s;
	}
}
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Complex cm1 = new Complex();
		Complex cm2 = new Complex(1);
		Complex cm3 = new Complex(3, 1);
		
		cm1.addComplex(cm2);
		cm2.mulComplex(cm3);
		System.out.println(cm1.toString());
		System.out.println(cm2.toString());
	}

}
