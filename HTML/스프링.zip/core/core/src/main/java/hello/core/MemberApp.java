package hello.core;

import hello.core.member.Grade;
import hello.core.member.Member;
import hello.core.member.MemberService;
import hello.core.member.MemberServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MemberApp {
    public static void main(String[] args) {
        //MemberService memberService = new MemberServiceImpl();

        //AppConfig appConfig = new AppConfig();
        //MemberService memberService = appConfig.memberService();

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext (AppConfig.class);
        MemberService memberService = applicationContext.getBean("memberService", MemberService.class);

        Member member = new Member(1L, "memberA", Grade.VIP);
        memberService.join(member);
        Member findMember = memberService.findMember(1L);
        System.out.println("new member = " + member.getName());
        System.out.println("find Member = " + findMember.getName());
    }
}
// 애플리케이션 로직(자바)으로 이렇게 테스트 하는 것은 좋은 방법이 아니다. JUnit 테스트를 사용하자

//      회원 도메인 설계의 문제점
//      이 코드의 설계상 문제점은 무엇일까요?
//      -자바코드로만 이루어져 실행하면 무조건 성공하고 비교를 따로 출력해주며 무엇을 테스트하는지 모르겠음

//      다른 저장소로 변경할 때 OCP 원칙을 잘 준수할까요?
//      +개방+폐쇄 원칙이란 소프트웨어 개체(클래스, 함수, 모듈)확장에 대해 열려 있어야 하고, 수정에 대해서는 닫혀 있어야 한다
//        즉 DI를 잘하기 위해서 개체만 바꿔야지 수정이 되면 기본틀이 파괴될거 같음
//      -관리를 스프링부트가 해줘야하는데 아직 사용하지 않아 의존 관계문제가 있음


//      DIP(DI패턴)를 잘 지키고 있을까요?
//      +이란 사용하면 기존 코드를 전혀 손대지 않고, 설정만으로 구현 클래스를 변경할 수 있다
//      -하지만 아직까지 스프링부트를 사용하지 않아 주사라는 개념이 없는거 같음


//      의존관계가 인터페이스 뿐만 아니라 구현까지 모두 의존하는 문제점이 있음
//      주문까지 만들고나서 문제점과 해결 방안을 설명