package hello.core;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import static org.springframework.context.annotation.ComponentScan.*;

@Configuration
@ComponentScan(
        basePackages =  {"hello.core"},
        basePackageClasses = AutoAppConfig.class,
        excludeFilters = @Filter(type = FilterType.ANNOTATION, classes = Configuration.class))
public class AutoAppConfig {

}
// 스프링부트를 사용하면 coreApplication에 있는 컴포넌트에 스캔이 포함되어 있어 따로 만들 필요없다.
// 스캔을 통해서 각 클래스에 컴포넌트를 읽는다 그리고 스프링 빈에 등록후 객체 생성시 오토와이어로 파라미터값을 빈에 등록된 것을 쓰게 만듬

//컴포넌트 스캔은 @Component 뿐만 아니라 다음과 내용도 추가로 대상에 포함한다.
//@Component : 컴포넌트 스캔에서 사용
//@Controlller : 스프링 MVC 컨트롤러에서 사용
//@Service : 스프링 비즈니스 로직에서 사용
//@Repository : 스프링 데이터 접근 계층에서 사용
//@Configuration : 스프링 설정 정보에서 사용

//FilterType
//        ANNOTATION: 기본값, 애노테이션을 인식해서 동작한다.
//        ex) org.example.SomeAnnotation
//        ASSIGNABLE_TYPE: 지정한 타입과 자식 타입을 인식해서 동작한다.
//        ex) org.example.SomeClass
//        ASPECTJ: AspectJ 패턴 사용
//        ex) org.example..*Service+
//        REGEX: 정규 표현식
//        ex) org\.example\.Default.*
//        CUSTOM: TypeFilter 이라는 인터페이스를 구현해서 처리
//        ex) org.example.MyTypeFilte