package hello.core.order;

import hello.core.annotataion.MainDiscountPolicy;
import hello.core.discount.DiscountPolicy;
import hello.core.discount.FixDiscountPolicy;
import hello.core.discount.RateDiscountPolicy;
import hello.core.member.Member;
import hello.core.member.MemberRepository;
import hello.core.member.MemoryMemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService{
    //private final DiscountPolicy discountPolicy = new FixDiscountPolicy ();
    //private final DiscountPolicy discountPolicy = new RateDiscountPolicy ();
    private final MemberRepository memberRepository;
    private final DiscountPolicy discountPolicy;
    // 필드 명칭을 같게 하던지 = rateDiscountPolicy
    // @Qualifier("mainDiscountPolicy") 다른이름으로 설정한 것을 추가해 넣는다. = @MainDiscountPolicy
    // @Primary 우선권을 가진다.

/* 롬북라이브러리 @RequiredArgsConstructor

   @Autowired
    public OrderServiceImpl(MemberRepository memberRepository, DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }
*/
    @Override
    public Order createOrder(Long memberId, String itemName, int itemPrice) {
        Member member = memberRepository.findById (memberId); //데이터확인
        int discountPrice = discountPolicy.discount (member, itemPrice); //할인

        return new Order (memberId, itemName, itemPrice, discountPrice);
    }
}
//    문제점 발견
//    우리는 역할과 구현을 충실하게 분리했다. OK
//     다형성도 활용하고, 인터페이스와 구현 객체를 분리했다. OK
//     OCP, DIP 같은 객체지향 설계 원칙을 충실히 준수했다 -> 그렇게 보이지만 사실은 아니다.
//        DIP: 주문서비스 클라이언트( OrderServiceImpl )는 DiscountPolicy 인터페이스에 의존하면서 DIP를 지킨 것 같은데?
//        클래스 의존관계를 분석해 보자. 추상(인터페이스) 뿐만 아니라 구체(구현) 클래스에도 의존하고 있다.
//        DIP 위반 추상에만 의존하도록 변경(인터페이스에만 의존) / DIP를 위반하지 않도록 인터페이스에만 의존하도록 의존관계를 변경하면 된다.
//        추상(인터페이스) 의존: DiscountPolicy
//        구체(구현) 클래스: FixDiscountPolicy , RateDiscountPolicy

//        OCP: 변경하지 않고 확장할 수 있다고 했는데!
//        지금 코드는 기능을 확장해서 변경하면, 클라이언트 코드에 영향을 준다! 따라서 OCP를 위반한다.