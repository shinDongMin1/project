package hello.core;

import hello.core.discount.DiscountPolicy;
import hello.core.discount.FixDiscountPolicy;
import hello.core.discount.RateDiscountPolicy;
import hello.core.member.MemberRepository;
import hello.core.member.MemberService;
import hello.core.member.MemberServiceImpl;
import hello.core.member.MemoryMemberRepository;
import hello.core.order.OrderService;
import hello.core.order.OrderServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public MemberService memberService() {
        return new MemberServiceImpl(memberRepository());
    }
    @Bean
    public OrderService orderService() {
        return new OrderServiceImpl(memberRepository(), discountPolicy());
    }

    //리팩터링: 중복되는 것을 제거, 역할에 따른 구현이 보이도록 함(결과는 같지만 구조를 바꿈)
    @Bean
    public MemberRepository memberRepository() {
        return new MemoryMemberRepository ();
    }

    //@Bean(name = "")
    @Bean
    public DiscountPolicy discountPolicy() {
        //return new FixDiscountPolicy ();
        return new RateDiscountPolicy ();
    }
}
//AppConfig의 등장으로 애플리케이션이 크게 사용 영역과, 객체를 생성하고 구성(Configuration)하는 영역으로 분리되었다.

//좋은 객체 지향 설계의 5가지 원칙의 적용
//여기서 3가지 SRP, DIP, OCP 적용
//SRP 단일 책임 원칙-한 클래스는 하나의 책임만 가져야 한다.
//DIP(inversion) 의존관계 역전 원칙-프로그래머는 “추상화에 의존해야지, 구체화에 의존하면 안된다.” 의존성 주입(DI)은 이 원칙을 따르는 방법 중 하나다
//OCP-소프트웨어 요소는 확장에는 열려 있으나 변경에는 닫혀 있어야 한다

//IoC-프로그램의 제어 흐름을 직접 제어하는 것이 아니라 외부(config)에서 관리하는 것
//프레임워크: 외부에서 제어 / 라이브러리: 내부(내가 짠 코드)에서 제어
//DI-는 정적인 클래스 의존 관계(추상화-선)와, 실행 시점에 결정되는 동적인 객체(인스턴스-점선) 의존 관계 둘을 분리

//AppConfig를 IoC 컨테이너 또는 DI 컨테이너라고한다.

