package hello.core.singleton;

import hello.core.AppConfig;
import hello.core.member.MemberService;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.assertj.core.api.Assertions.assertThat;

public class SingletonService {
    //1. static 영역에 객체를 딱 1개만 생성해둔다.
    private static final SingletonService instance = new SingletonService();
    //2. public으로 열어서 객체 인스터스가 필요하면 이 static 메서드를 통해서만 조회하도록 허용한다.
    public static SingletonService getInstance() {
        return instance;
    }
    //3. 생성자를 private으로 선언해서 외부에서 new 키워드를 사용한 객체 생성을 못하게 막는다.
    private SingletonService() {
    }
    public void logic() {
        System.out.println("싱글톤 객체 로직 호출");
    }

    @Test
    @DisplayName("싱글톤 패턴을 적용한 객체 사용")
    public void singletonServiceTest() {
        //private으로 생성자를 막아두었다. 컴파일 오류가 발생한다.
        //new SingletonService();

        //1. 조회: 호출할 때 마다 같은 객체를 반환
        SingletonService singletonService1 = SingletonService.getInstance();

        //2. 조회: 호출할 때 마다 같은 객체를 반환
        SingletonService singletonService2 = SingletonService.getInstance();

        //참조값이 같은 것을 확인
        System.out.println("singletonService1 = " + singletonService1);
        System.out.println("singletonService2 = " + singletonService2);

        // singletonService1 == singletonService2
        assertThat(singletonService1).isSameAs(singletonService2);
        singletonService1.logic();
    }

    @Test
    @DisplayName("스프링 컨테이너와 싱글톤")
    void springContainer() {
        ApplicationContext ac = new
                AnnotationConfigApplicationContext (AppConfig.class);
        //1. 조회: 호출할 때 마다 같은 객체를 반환
        MemberService memberService1 = ac.getBean("memberService",
                MemberService.class);

        //2. 조회: 호출할 때 마다 같은 객체를 반환
        MemberService memberService2 = ac.getBean("memberService",
                MemberService.class);

        //참조값이 같은 것을 확인
        System.out.println("memberService1 = " + memberService1);
        System.out.println("memberService2 = " + memberService2);

        //memberService1 == memberService2
        assertThat(memberService1).isSameAs(memberService2);
    }

}
// 스프링없이 DI컨테이너(트래픽마다 1개)를 싱글톤패턴(전체 1개)으로 바꾸고 테스트하기에는 각 빈마다 코드를 추가하고
// 의존관계상 구체 클래스에 의존해서 DIP, OCP원칙을 깨며 유연성이 떨어짐

// 스프링 DI컨테이너는 앞에서 빈에 생성자를 만들어서 복잡해졋는데 이것은 싱글톤을 위해서 기회비용차이로 선택한것
// @Config와 바이트코드 조작으로 자바코드를 조작해서 같은것은 1번만 사용되게함 = 싱글톤이 보장
// AnnotationConfigApplicationContext에 메타데이터(BeanDefinition)를 파라미터로 넘긴 값에 AppConfig가 있어 빈으로 설정
// 그런데 CGLIB라이브러리로 해당 빈을 조작해서 다른 클래스를 등록한것이었음.
// bean = class hello.core.AppConfig$$EnhancerBySpringCGLIB$$bd479d70

// 하지만 싱글톤을 하면 빈의 서비스 사용중 동기화 문제가 발생 -> 무상태유지해야함(다른사람이 사용해도 내가 받는 값은 일정해야함)