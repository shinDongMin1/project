fun main() {
    var var1:Int = 10

    println(var1)
}