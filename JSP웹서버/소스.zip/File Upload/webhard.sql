create table webhard (
    num   int          auto_increment primary key,
    fname varchar(80), 
    ftime varchar(20),
    fsize int
); 